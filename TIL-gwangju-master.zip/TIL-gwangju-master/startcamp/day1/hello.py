greeting = '안녕하세요!'

# 1. while문 반복
# count = 0
# while count < 5:
#     print(greeting)
#     count = count + 1

# 2. for문 반복
# count_list = [0, 1, 2, 3]
# for num in count_list:
#     print(greeting)

# 3. for문 반복 (함수 활용)
for num in range(4):
    print(greeting)